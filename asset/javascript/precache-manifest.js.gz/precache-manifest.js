self.__precacheManifest = [
    // {
    //     "revision": "1.0.0",
    //     "url": "https://aidans-personal-website.disqus.com/count.js",
    // }, 
    // {
    //     "revision": "1.0.0",
    //     "url": "https://aidans-personal-website.disqus.com/embed.js",
    // }, 
    {
        "revision": "1.0.0",
        "url": "/asset/javascript/index.js",
    }, 
    {
        "revision": "8.0.1",
        "url": "https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css",
    },
    {
        "revision": "4.6.3",
        "url": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css",
    },
    {
        "revision": "4.6.3",
        "url": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/fonts/fontawesome-webfont.woff2",
    },
    {
        "revision": "1.0.0",
        "url": "/asset/style/index.css",
    }, 
    {
        "revision": "3.7.0",
        "url": "https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js",
    }, 
    {
        "revision": "1.4.2",
        "url": "https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js",
    }, 
    // {
    //     "revision": "2.0",
    //     "url": "https://bdimg.share.baidu.com/static/api/js/share.js",
    // },
    {
        "revision": "1.0.0",
        "url": "/asset/vendor/magicthumb/magicthumb.css",
    }, 
    {
        "revision": "1.0.0",
        "url": "/asset/vendor/magicthumb/magicthumb.js",
    }, 
    {
        "revision": "3.1.1",
        "url": "/asset/vendor/jquery-3.1.1/jquery-3.1.1.min.js",
    }, 
    {
        "revision": "1.0.0",
        "url": "/asset/vendor/magicthumb/magicthumb.jekyll.js",
    },
    {
        "revision": "0.10.1",
        "url": "https://cdnjs.cloudflare.com/ajax/libs/fetch/0.10.1/fetch.min.js",
    },
    {
        "revision": "4.5.3",
        "url": "/asset/vendor/unsplash-js/4.5.3/unsplash.min.js",
    },
    // {
    //     "revision":   "1.0.0",      
    //     "url": "https://www.googletagmanager.com/gtag/js/g.js",
    // },
    // {
    //     "revision":   "1.0.0",      
    //     "url": "https://www.google-analytics.com/analytics.js",
    // },
    {
        "revision":   "1.0.0",      
        "url": "/favicon.ico",
    },
    {
        "revision": "1.0.0",
        "url": "/index.html",
    }, 
    {
        "revision": "1.0.0",
        "url": "/asset/image/container-bg.png",
    },
    {
        "revision": "1.0.0",
        "url": "/asset/image/blog/blog-bg-001.jpg",
    },
    {
        "revision": "1.0.0",
        "url": "/asset/image/share/share-bg-002.jpg",
    },
    {
        "revision": "1.0.0",
        "url": "/asset/image/about/about-bg-001.jpg",
    }, 
];
